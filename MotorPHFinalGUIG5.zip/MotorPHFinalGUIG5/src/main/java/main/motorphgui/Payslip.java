/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.motorphgui;

/**
 *
 * @author Kristel
 */
public class Payslip {
     private int employeeId;
    private float grossPay;
    private float tax;
    private float netPay;

    public Payslip(int employeeId, float grossPay, float tax, float netPay) {
        this.employeeId = employeeId;
        this.grossPay = grossPay;
        this.tax = tax;
        this.netPay = netPay;
    }

    // Getters and Setters
    
}
